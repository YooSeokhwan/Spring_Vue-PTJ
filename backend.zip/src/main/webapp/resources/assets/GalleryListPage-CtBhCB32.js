import{_ as e,o as r,d as a}from"./index-I6TbVDK2.js";const c={};function n(t,o){return r(),a("main",null,"Gallery")}const s=e(c,[["render",n]]);export{s as default};
