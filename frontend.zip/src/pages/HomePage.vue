<script setup></script>

<template>
  <div>첫번째 페이지</div>
</template>
