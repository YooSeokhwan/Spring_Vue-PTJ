<script setup></script>

<template>
  <main>Gallery</main>
</template>
